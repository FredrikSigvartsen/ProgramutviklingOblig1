//Navn: Elias A. Thøgersen  //Navn: Jens Omfjord        //Navn: Fredrik Sigvartsen
//Stud.Nummer: s236603      //Stud.Nummer: s236641      //Stud.Nummer: s236356
//Klasse: INFORMATIK14HA    //Klasse: INFORMATIK14HA    //Klasse: HINGDATA14HA

package oppgave1;
import java.awt.event.*;
import javax.swing.*;

public class Biblotek_Driver
{
  public static void main( String[] args )
  {
    Bokregister hioa = new Bokregister();
    final BokVindu v = new BokVindu(hioa);
            v.addWindowListener(
      new WindowAdapter() {
        public void windowClosing( WindowEvent e )
        {
          v.skrivTilFil();
          System.exit( 0 );
        }
      } );
  }
}