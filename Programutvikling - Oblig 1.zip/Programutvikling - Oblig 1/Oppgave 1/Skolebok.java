//Navn: Elias A. Thøgersen  //Navn: Jens Omfjord        //Navn: Fredrik Sigvartsen
//Stud.Nummer: s236603      //Stud.Nummer: s236641      //Stud.Nummer: s236356
//Klasse: INFORMATIK14HA    //Klasse: INFORMATIK14HA    //Klasse: HINGDATA14HA

package oppgave1;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Skolebok extends Bok  {
    
    private int klassetrinn;
    private String skolefag;
    
    public Skolebok(){
        
    }
    
    public Skolebok(String forfatter, String tittel, int sideantall, double pris, int klassetrinn, String skolefag){
        super(forfatter, tittel, sideantall, pris);
        this.klassetrinn = klassetrinn;
        this.skolefag = skolefag;
    }

    public int getKlassetrinn() {
        return klassetrinn;
    }

    public String getSkolefag() {
        return skolefag;
    }

    @Override
    public String toString() {
        return super.toString() + "\n   Kategori: Skolebok\n   Klassetrinn: "+ klassetrinn
                + "\n   Skolefag: " + skolefag;
    }
    
    public boolean lesObjektFraFil( DataInputStream inputFil ){  //  Leser verdier fra fil og lagrer dem i de tilhørende datafeltene. >
        
        try{
          super.lesObjektFraFil(inputFil);
          skolefag = inputFil.readUTF();
          klassetrinn = inputFil.readInt();
        }
        catch ( FileNotFoundException fnfe ){
          return false;
        }
        catch ( EOFException eofe ){
          return false;
        }
        catch ( IOException ioe ){
          return false;
        }
    return true;
    } // end of method lesObjektFraFil

    public void skrivObjektTilFil( DataOutputStream outputFil ) throws IOException{  // Skriver datafeltenes verdier til fil. >
        
        outputFil.writeUTF("Skolebok");
        super.skrivObjektTilFil(outputFil);
        outputFil.writeUTF(skolefag);
        outputFil.writeInt( klassetrinn);
    }
    
}
