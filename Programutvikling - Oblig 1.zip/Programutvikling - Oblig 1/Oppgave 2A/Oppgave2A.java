//Navn: Elias A. Thøgersen  //Navn: Jens Omfjord        //Navn: Fredrik Sigvartsen
//Stud.Nummer: s236603      //Stud.Nummer: s236641      //Stud.Nummer: s236356
//Klasse: INFORMATIK14HA    //Klasse: INFORMATIK14HA    //Klasse: HINGDATA14HA

package oppgave2a;
import java.awt.event.*;

public class Oppgave2A {

    public static void main(String[] args) {
        
        final Brukergrensesnitt vindu = new Brukergrensesnitt();

        vindu.addWindowListener(
            new WindowAdapter() {
                public void windowClosing(WindowEvent e){
                    vindu.skrivTilFil();
                    System.exit( 0 );
                }
        } );
    }
}//end of class Oppgave2A
