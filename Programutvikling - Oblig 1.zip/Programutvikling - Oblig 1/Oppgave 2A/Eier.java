//Navn: Elias A. Thøgersen  //Navn: Jens Omfjord        //Navn: Fredrik Sigvartsen
//Stud.Nummer: s236603      //Stud.Nummer: s236641      //Stud.Nummer: s236356
//Klasse: INFORMATIK14HA    //Klasse: INFORMATIK14HA    //Klasse: HINGDATA14HA

package oppgave2a;
import java.io.Serializable;

//Klassen skal lagre data om eiere
public class Eier implements Serializable{
    
    //Nødvendige datafelt
    private static final long serialVersionUID = 123L;
    private int medlemsNr;
    private static int nesteNr = 1;
    private String navn;
    private String adresse;
    private Båt båt;
    Eier neste;
    
    //Knostruktør
    public Eier(String navn, String adresse) {
        
        medlemsNr = nesteNr++;
        this.navn = navn;
        this.adresse = adresse;
        båt = null;
    }
    
    //Get-metoder
    public static int getNr() {
        return nesteNr;
    }
    
    public static void setNr(int nr) {
        nesteNr = nr;
    }
        
    
    public int getMedlemsNr() {
        return this.medlemsNr;
    }
    
    public Båt getBåt() {
        return this.båt;
    }
    
    //Set-metode
    public void setBåt(Båt båt) {
        this.båt = båt;
    }
    
    public String toString() {
        return "Navn: " + this.navn + 
               "\nAdresse: " + this.adresse + 
               "\nMedlemsNr: " + this.medlemsNr + 
               "\nBåt: " + (båt != null ? "\n" + båt.toString() : "Ingen båt registrert");
    }
}//end of class Eier
