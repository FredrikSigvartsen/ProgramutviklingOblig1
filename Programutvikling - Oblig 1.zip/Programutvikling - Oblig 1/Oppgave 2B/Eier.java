//Navn: Elias A. Thøgersen  //Navn: Jens Omfjord        //Navn: Fredrik Sigvartsen
//Stud.Nummer: s236603      //Stud.Nummer: s236641      //Stud.Nummer: s236356
//Klasse: INFORMATIK14HA    //Klasse: INFORMATIK14HA    //Klasse: HINGDATA14HA

package oppgave2b;
import java.io.Serializable;

//Klassen skal lagre data om eiere
public class Eier implements Serializable{
    
    //Nødvendige datafelt
    private static final long serialVersionUID = 321L;
    private int medlemsNr;
    private static int nesteNr = 1;
    private String navn;
    private String adresse;
    private Båtliste båter;
    Eier neste;
    
    //Konstruktør
    public Eier(String navn, String adresse) {
        
        medlemsNr = nesteNr++;
        this.navn = navn;
        this.adresse = adresse;
        båter = null;
    }
    
    public static int getNr() {
        return nesteNr;
    }
    
    public static void setNr(int nr) {
        nesteNr = nr;
    }
        
    
    public int getMedlemsNr() {
        return this.medlemsNr;
    }
    
    public Båtliste getBåtliste() {
        return this.båter;
    }
    
    public void settInnBåt(Båt båt) {
        if(this.båter == null)
            this.båter = new Båtliste();
        this.båter.settInnBåt(båt);
    }
    
    public void slettBåtliste() {
        this.båter = null;
    }
    
    public String toString() {
        return "Navn: " + this.navn + 
               "\nAdresse: " + this.adresse + 
               "\nMedlemsNr: " + this.medlemsNr + 
               "\nBåt: " + (båter != null ? "\n" + båter.toString() : "Ingen båt registrert\n");
    }
}//end of class Eier
