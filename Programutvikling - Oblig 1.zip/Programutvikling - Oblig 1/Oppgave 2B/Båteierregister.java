//Navn: Elias A. Thøgersen  //Navn: Jens Omfjord        //Navn: Fredrik Sigvartsen
//Stud.Nummer: s236603      //Stud.Nummer: s236641      //Stud.Nummer: s236356
//Klasse: INFORMATIK14HA    //Klasse: INFORMATIK14HA    //Klasse: HINGDATA14HA

package oppgave2b;
import java.io.Serializable;

//Liste-klasse for båteiere
public class Båteierregister implements Serializable {
    
    private static final long serialVersionUID = 234L;
    private Eier første;

    public Båteierregister(){
        første = null;
    }

    public void settInn( Eier ny ){
        if ( første == null )
            første = ny;
        else
        {
            Eier løper = første;
            while ( løper.neste != null )
                løper = løper.neste;
            løper.neste = ny;
        }
    }

    public String eierInfo(int medlemsNr){
        Eier løper = første;
        while(løper != null && løper.getMedlemsNr() != medlemsNr){
            løper = løper.neste;
        }
        return løper.toString();
    }
    
    public String visRegister() {
        String ut = "";
        Eier løper = første;

        while ( løper != null ){
            ut += løper.toString() + "\n";
            løper = løper.neste;
        }

        if ( !ut.equals( "" ) )
            return ut;
        else
            return "Registeret er tomt";
    }

    public Eier finnEier(int medlemsNr){
        Eier løper = første;
        while(løper != null && løper.getMedlemsNr() != medlemsNr) {
            løper = løper.neste;
        }
        return løper;
    }
    
    public Eier finnEier(Båt båt) {
        Eier løper = første;
        while(løper != null) {
            if(løper.getBåtliste() != null && løper.getBåtliste().finnBåt(båt) != null)
                return løper;
            else
                løper = løper.neste;
        }
        return null;
    }
    
    public Båt finnBåt(int regNr) {
        Eier løper = første;
        while(løper != null) {
            if(løper.getBåtliste() != null && løper.getBåtliste().finnBåt(regNr) != null) {
               return løper.getBåtliste().finnBåt(regNr);
            }
            løper = løper.neste;
        }
        return null;
    }
    
    public boolean fjernBåt( Båt båt ) {
        
        Eier eier = finnEier(båt);
        boolean ok = false;
        if(eier == null) {
            return ok;
        } else if(eier.getBåtliste() != null){
            ok = eier.getBåtliste().fjernBåt(båt, eier);
        }
        return ok;
    }
    
    public String fjernEier(Eier eier) {
        
        if(eier.getBåtliste() == null) {
            if (første == null)
                return "Registeret er tomt";

            if (første == eier) {
                første = første.neste;
                return "Eieren ble slettet";
            }

            Eier løper = første;

            while (løper.neste != null) {
                if (løper.neste == eier) {
                    løper.neste = løper.neste.neste;
                    return "Eieren ble slettet";
                } else
                    løper = løper.neste;
            }
            return "Her skjedde det noe";
        }
        else
            return "Eieren eier en båt, og kan derfor ikke fjernes!";
    }

    public String eierSkifte(int regNr, int medlemsNr){
        
        Båt skiftebåt = finnBåt(regNr);
        Eier eier = finnEier(medlemsNr);
        Eier gammelEier = finnEier(skiftebåt);
        
        if(eier == null){
            return "Den nye eieren må registreres";
        }
        else if(skiftebåt == null) {
            return "Fant ikke båt med regNr: " + regNr;
        } else {
            eier.settInnBåt(skiftebåt);
            gammelEier.getBåtliste().fjernBåt(skiftebåt, gammelEier);
            return "Båten har skiftet eier";
        }
    }
}//end of class Båteierregister
