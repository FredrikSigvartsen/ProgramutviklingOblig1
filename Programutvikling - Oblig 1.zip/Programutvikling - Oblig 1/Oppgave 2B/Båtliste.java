//Navn: Elias A. Thøgersen  //Navn: Jens Omfjord        //Navn: Fredrik Sigvartsen
//Stud.Nummer: s236603      //Stud.Nummer: s236641      //Stud.Nummer: s236356
//Klasse: INFORMATIK14HA    //Klasse: INFORMATIK14HA    //Klasse: HINGDATA14HA

package oppgave2b;
import java.io.Serializable;

//Liste-klasse for båter
public class Båtliste implements Serializable{
    
    private static final long serialVersionUID = 555L;
    private Båt første;
    
    public Båtliste() {
        første = null;
    }
    
    public void settInnBåt(Båt ny) {
        if ( første == null )
            første = ny;
        else
        {
            Båt løper = første;
            while ( løper.neste != null )
                løper = løper.neste;
            løper.neste = ny;
        }
    }
    
    public Båt finnBåt(int regNr) {
        Båt løper = første;
        while(løper != null && løper.getRegNr() != regNr)
            løper = løper.neste;
        
        if(løper != null)
            return løper;
        else 
            return null;
    }
    
    public Båt finnBåt(Båt båt) {
        Båt løper = første;
        if(løper == null)
            return null;
        while(løper != null) {
            if(løper.getRegNr() == båt.getRegNr())
                return løper;
            løper = løper.neste;
        }
        return null;
    }
    
    public boolean fjernBåt(Båt båt, Eier eier) {
        if(første == null)
            return false;
        if(første.getRegNr() == båt.getRegNr()) {
            første = første.neste;
            eier.slettBåtliste();
            return true;
        }
        Båt løper = første;
        while(løper.neste != null) {
            if(løper.neste.getRegNr() == båt.getRegNr()) {
                løper.neste = løper.neste.neste;
                return true;
            }
            løper = løper.neste;
        }
        return false;
    }
    
    public String toString() {
        
        String tekst = "";
        
        Båt løper = første;
        
        while(løper != null) {
            tekst += løper.toString();
            løper = løper.neste;
        }
        return tekst;
    }
}//end of class Båtliste
