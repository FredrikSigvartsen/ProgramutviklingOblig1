//Jens Omfjord s236641 INFORMATIK14HA
//Elias Thøgersen s236641 INFORMATIK14HA
//Fredrik Sigvartsen s236356 HINGDATA14HA

package programutvikling.oblig.pkg1;
import java.awt.event.*;

public class ProgramutviklingOblig1 {         //Driverklassen

    public static void main(String[] args) {
        
        final Brukergrensesnitt vindu = new Brukergrensesnitt();

        vindu.addWindowListener(
            new WindowAdapter() {
                public void windowClosing(WindowEvent e){
                    vindu.skrivTilFil();
                    System.exit( 0 );
                }
        } );
    }
}//end of class
